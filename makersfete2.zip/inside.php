<?php
session_start();
$d=0;
$a=$_SESSION['name'];
if(empty($a))
{
	header("location:admin.php");
	
	
}
else
{$d=1;}

?>



<?php if($d==1){echo "hello ".$a;} ?>
<br>
<a href="?logout" class="button outline-inward">logout</a>
<?php if(isset($_GET['logout'])){session_destroy();header("location:admin.php");} ?>