
   var count=0;
           var colour=["blue","red"];
           
       function change()
       {
           
           document.getElementById("change").style.color="blue";
         setTimeout("colorchange()",700);
           
           
       }
       function colorchange()
       {
           document.getElementById("change").style.color="white";
           setTimeout("change()",700);
       }
	   
	    function hange()
       {
           
           document.getElementById("hange").style.color="#00C";
         setTimeout("colorhange()",700);
           
           
       }
       function colorhange()
       {
           document.getElementById("hange").style.color="white";
           setTimeout("hange()",700);
       }
       
       
   
    